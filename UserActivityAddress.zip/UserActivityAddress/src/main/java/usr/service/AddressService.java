package usr.service;

import java.util.List;

import org.springframework.data.domain.Page;

import usr.model.Address;

public interface AddressService {

	Address findOne(Long id);
	
	List<Address> findAll();
	
	List<Address> save(List<Address> list);
	
	Address save(Address address);
	
	Address delete(Long id);
	
	void delete(List<Long> ids);
	
	List<Address> findByNameAndNumber(String name, String number);
	
	List<Address> findByUserId(Long id);

	Page<Address> findAll(int page);
}
