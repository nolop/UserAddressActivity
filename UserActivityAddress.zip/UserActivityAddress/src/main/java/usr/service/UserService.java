package usr.service;

import java.util.List;

import org.springframework.data.domain.Page;

import usr.model.User;

public interface UserService {

	User findOne(Long id);
	
	User save(User user);
	
	List<User> save(List<User> users);
	
	User delete(Long id);
	
	void delete(List<Long> ids);
	
	List<User> findByName(String name);
	
	Page<User> findAll(int page);
}
