package usr.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import usr.model.User;
import usr.repository.UserRepository;
import usr.service.UserService;

@Service
@Transactional
public class JpaUserService implements UserService{

	@Autowired
	private UserRepository urep;
	
	@Override
	public User findOne(Long id) {
		return urep.findOne(id);
	}

	@Override
	public User save(User user) {
		return urep.save(user);
	}

	@Override
	public User delete(Long id) {
		User deleted = urep.findOne(id);
		if(deleted==null)
			return null;
		else{
			urep.delete(id);
			return deleted;
		}			
	}

	@Override
	public void delete(List<Long> ids) {
		for(Long id : ids)
			delete(id);
	}

	@Override
	public List<User> findByName(String name) {
		return urep.findByFirstnameContaining(name);
	}

	@Override
	public List<User> save(List<User> users) {
		List<User> ret= new ArrayList<User>();
		for(User uss : users){
			User user = save(uss);
			ret.add(user);
		}			
		return ret;
	}

	@Override
	public Page<User> findAll(int page) {
		return urep.findAll(new PageRequest(page, 10));
	}

}
