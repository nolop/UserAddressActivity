package usr.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import usr.model.Activity;
import usr.repository.ActivityRepository;
import usr.service.ActivityService;

@Service
@Transactional
public class JpaActivityService implements ActivityService{

	@Autowired
	private ActivityRepository arep;
	
	@Override
	public Activity findOne(Long id) {
		return arep.findOne(id);
	}
	
	@Override
	public Page<Activity> findAll(int page) {
		return arep.findAll(new PageRequest(page, 10));
	}

	@Override
	public List<Activity> save(List<Activity> list) {
		List<Activity> ret = new ArrayList<Activity>();
		for(Activity act : list){
			Activity acti = save(act);
			ret.add(acti);
		}
		return ret;
	}
	/*
	@Override
	public List<Activity> findAll() {
		return arep.findAll();
	}

	@Override
	public List<Activity> save(List<Activity> list) {
		return arep.save(list);
	}
	*/
	@Override
	public Activity save(Activity activity) {
		return arep.save(activity);
	}

	@Override
	public Activity delete(Long id) {
		Activity deleted = arep.findOne(id);
		if(deleted!=null){
			arep.delete(deleted);
			return deleted;
		}
		return null;
	}

	@Override
	public void delete(List<Long> ids) {
		for(Long id : ids)
			delete(id);
	}

	@Override
	public List<Activity> findByName(String name) {
		return arep.findByNameContaining(name);
	}

	@Override
	public List<Activity> findAll() {
		return arep.findAll();
	}

	
	
}
