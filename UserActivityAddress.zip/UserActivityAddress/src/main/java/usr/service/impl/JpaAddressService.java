package usr.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import usr.model.Address;
import usr.repository.AddressRepository;
import usr.service.AddressService;

@Service
@Transactional
public class JpaAddressService implements AddressService{

	@Autowired
	private AddressRepository adrep;

	@Override
	public Address findOne(Long id) {
		return adrep.findOne(id);
	}
	
	@Override
	public Page<Address> findAll(int page) {
		return adrep.findAll(new PageRequest(page, 10));
	}

	@Override
	public List<Address> save(List<Address> list) {
		List<Address> ret = new ArrayList<Address>();
		for(Address addr : list){
			Address addd = save(addr);
			ret.add(addd);
		}
		return ret;
	}
	/*
	@Override
	public List<Address> findAll() {
		return adrep.findAll();
	}

	@Override
	public List<Address> save(List<Address> list) {
		return adrep.save(list);
	}
	*/
	@Override
	public Address save(Address address) {
		return adrep.save(address);
	}

	@Override
	public Address delete(Long id) {
		Address deleted = adrep.findOne(id);
		if(deleted!=null){
			adrep.delete(deleted);
			return deleted;
		}
		return null;
	}

	@Override
	public void delete(List<Long> ids) {
		for(Long id : ids)
			delete(id);
	}
	
	@Override
	public List<Address> findByNameAndNumber(String name, String number) {
		return adrep.findByStreetAndNumber(name, number);
	}

	@Override
	public List<Address> findByUserId(Long id) {
		return adrep.findByUserId(id);
	}

	@Override
	public List<Address> findAll() {
		return adrep.findAll();
	}
}
