package usr.service;

import java.util.List;

import org.springframework.data.domain.Page;

import usr.model.Activity;

public interface ActivityService{

	Activity findOne(Long id);
	
	List<Activity> findAll();
	
	List<Activity> save(List<Activity> list);
	
	Activity save(Activity activity);
	
	Activity delete(Long id);
	
	void delete(List<Long> ids);
	
	List<Activity> findByName(String name);

	Page<Activity> findAll(int page);
}
