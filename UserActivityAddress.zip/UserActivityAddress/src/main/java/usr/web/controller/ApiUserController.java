package usr.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import usr.model.Address;
import usr.model.User;
import usr.service.AddressService;
import usr.service.UserService;
import usr.support.UserDtoToUser;
import usr.support.UserToUserDto;
import usr.web.dto.UserDto;

@RestController
@RequestMapping(value="/api/users")
public class ApiUserController {

	@Autowired
	private UserService use;
	@Autowired
	private AddressService addre;
	
	@Autowired
	private UserDtoToUser toUser;
	@Autowired
	private UserToUserDto toDto;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<UserDto>> getUsers(@RequestParam(value="page", defaultValue="0") int page){
		Page<User> ret = use.findAll(page);
		
		if(ret==null || ret.getTotalPages()<page)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convertAll(ret.getContent()), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET, params="name")
	public ResponseEntity<List<UserDto>> getUsers(@RequestParam String name){
		List<User> ret = use.findByName(name);
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convertAll(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/{id}")
	public ResponseEntity<UserDto> getUser(@PathVariable Long id){
		User ret = use.findOne(id);
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST, consumes="application/json")
	public ResponseEntity<UserDto> addUsers(@RequestBody UserDto dto){
		User ret= use.save(toUser.convert(dto));
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(ret), HttpStatus.CREATED);
	}
	
	@RequestMapping(method=RequestMethod.PUT, consumes="application/json", value="{id}")
	public ResponseEntity<UserDto> editUser(@RequestBody UserDto dto, @PathVariable Long id){
		User ret = use.save(toUser.convert(dto));
		
		if(ret!=toUser.convert(dto))
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/{id}")
	public ResponseEntity<UserDto> deleteUser(@PathVariable Long id){
		List<Address> addresses = addre.findByUserId(id);
		if(!addresses.isEmpty()){
			List<Long> ids = new ArrayList<Long>();
			for(Address ad : addresses){
				ids.add(ad.getId());
			}
			addre.delete(ids);
		}
		User deleted = use.delete(id);
		
		if(deleted==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(deleted), HttpStatus.NO_CONTENT);
	}
}
