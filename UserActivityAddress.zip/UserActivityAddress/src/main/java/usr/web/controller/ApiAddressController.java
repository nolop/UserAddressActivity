package usr.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import usr.model.Address;
import usr.model.User;
import usr.service.AddressService;
import usr.service.UserService;
import usr.support.AddressDtoToAddress;
import usr.support.AddressToAddressDto;
import usr.web.dto.AddressDto;

@RestController
@RequestMapping(value="/api/addresses")
public class ApiAddressController {
	
	@Autowired
	private AddressService aser;
		
	@Autowired
	private UserService usser;
	
	@Autowired
	private AddressDtoToAddress toAdd;
	
	@Autowired
	private AddressToAddressDto toDto;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> getAddresses(){
		List<Address> ret = aser.findAll();
			if(ret==null)
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				return new ResponseEntity<>(toDto.convertAll(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/{id}")
	public ResponseEntity<AddressDto> getAddress(@PathVariable Long id){
		Address ret = aser.findOne(id);
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(toDto.convert(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/user/{userId}")
	public ResponseEntity<List<AddressDto>> getAddressUser(@PathVariable Long userId){
		List<Address> ret = aser.findByUserId(userId);
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(toDto.convertAll(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/user/{userId}", consumes="application/json")
	public ResponseEntity<AddressDto> addAddress(@RequestBody AddressDto dto, @PathVariable Long userId){
		
		User user = usser.findOne(userId);
		
		Address address = toAdd.convert(dto);
		
		user.addAddresses(address);
		
		Address persisted = aser.save(address);
		usser.save(user);
		
		if(persisted==null)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<>(toDto.convert(persisted), HttpStatus.CREATED);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/{id}/user/{userId}", consumes="application/json")
	public ResponseEntity<AddressDto> updateAddress(
			@PathVariable Long id,
			@PathVariable Long userId,			
			@RequestBody AddressDto newAdd){
		
		if(id==null || !id.equals(newAdd.getId())){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		Address address = toAdd.convert(newAdd);
		
		User user = usser.findOne(userId);
		
		user.addAddresses(address);
		
		Address persisted  = aser.save(address);
		
		return new ResponseEntity<>(toDto.convert(persisted), HttpStatus.CREATED);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/{id}")
	public ResponseEntity<AddressDto> deleteAddress(@PathVariable Long id){
		Address deleted = aser.findOne(id);
		
		if(deleted==null)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		
		aser.delete(id);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
/*
@RestController
@RequestMapping(value="/api/users/{userId}/addresses")
public class ApiAddressController {

	@Autowired
	private AddressService aser;
		
	@Autowired
	private UserService usser;
	
	@Autowired
	private AddressDtoToAddress toAdd;
	
	@Autowired
	private AddressToAddressDto toDto;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> getAddresses(@PathVariable Long userId){
		
		if(userId==0){
			List<Address> ret = aser.findAll();
			if(ret==null)
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				return new ResponseEntity<>(toDto.convertAll(ret), HttpStatus.OK);
		}
		
		List<Address> ret = aser.findByUserId(userId);
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(toDto.convertAll(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/{id}")
	public ResponseEntity<AddressDto> getAddress(@PathVariable Long id, @PathVariable Long userId){
		Address ret = aser.findOne(id);
		
		if(ret!=null && ret.getUser().getId()!=userId)
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		else
			return new ResponseEntity<>(toDto.convert(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST, consumes="application/json")
	public ResponseEntity<AddressDto> addAddress(@RequestBody AddressDto dto, @PathVariable Long userId){
		
		User user = usser.findOne(userId);
		
		Address address = toAdd.convert(dto);
		
		user.addAddresses(address);
		
		Address persisted = aser.save(address);
		usser.save(user);
		
		if(persisted==null)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		else
			return new ResponseEntity<>(toDto.convert(persisted), HttpStatus.CREATED);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/{id}", consumes="application/json")
	public ResponseEntity<AddressDto> updateAddress(
			@PathVariable Long userId,
			@PathVariable Long id,
			@RequestBody AddressDto newAdd){
		
		if(id==null || !id.equals(newAdd.getId())){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		Address address = toAdd.convert(newAdd);
		
		User user = usser.findOne(userId);
		
		user.addAddresses(address);
		
		Address persisted  = aser.save(address);
		
		//if(address.getUser().getId()!=userId)
			//return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		//else{
			
			return new ResponseEntity<>(toDto.convert(persisted), HttpStatus.CREATED);
		//}	
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/{id}")
	public ResponseEntity<AddressDto> deleteAddress(@PathVariable Long id, @PathVariable Long userId){
		Address deleted = aser.findOne(id);
		
		if(deleted==null || deleted.getUser().getId()!=userId)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		
		aser.delete(id);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
*/	
}
