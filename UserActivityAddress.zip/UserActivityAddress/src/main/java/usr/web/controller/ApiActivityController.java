package usr.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import usr.model.Activity;
import usr.service.ActivityService;
import usr.support.ActivityDtoToActivity;
import usr.support.ActivityToActivityDto;
import usr.web.dto.ActivityDto;

@RestController
@RequestMapping(value="/api/activities")
public class ApiActivityController {

	@Autowired
	private ActivityService ase;
	@Autowired
	private ActivityDtoToActivity toActivity;
	@Autowired
	private ActivityToActivityDto toDto;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<ActivityDto>> getActivities(@RequestParam(value="name", required=false)String name){
		List<Activity> ret = null;
		
		if(name!=null)
			ret = ase.findByName(name);
		else
			ret = ase.findAll();
		
		if(ret==null || ret.isEmpty())
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convertAll(ret), HttpStatus.OK);
	}
		
	@RequestMapping(method=RequestMethod.GET, value="/{id}")
	public ResponseEntity<ActivityDto> getActivity(@PathVariable Long id){
		Activity ret = ase.findOne(id);
		
		if(ret==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(ret), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.POST, consumes="application/json")
	public ResponseEntity<ActivityDto> addActivity(@RequestBody ActivityDto dto){
		Activity saved = ase.save(toActivity.convert(dto));
		
		if(saved==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(saved), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/{id}", consumes="application/json")
	public ResponseEntity<ActivityDto> editActivity(@PathVariable Long id, @RequestBody ActivityDto dto){
		Activity edited = ase.save(toActivity.convert(dto));
		
		if(edited!=toActivity.convert(dto))
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(edited), HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/{id}")
	public ResponseEntity<ActivityDto> deleteUser(@PathVariable Long id){
		Activity deleted = ase.delete(id);
		
		if(deleted==null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(toDto.convert(deleted), HttpStatus.OK);
	}
		
}
