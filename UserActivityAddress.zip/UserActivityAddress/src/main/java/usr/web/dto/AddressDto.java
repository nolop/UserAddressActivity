package usr.web.dto;


public class AddressDto {

	private Long id;
	private String street;
	private String number;
	private Long usrId;
	
	public AddressDto() {}

	public AddressDto(String street, String number) {
		this.street = street;
		this.number = number;
	}
	
	public Long getUsrId() {
		return usrId;
	}

	public void setUsrId(Long usrId) {
		this.usrId = usrId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
}
