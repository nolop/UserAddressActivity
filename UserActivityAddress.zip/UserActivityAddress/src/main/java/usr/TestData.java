package usr;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import usr.model.Activity;
import usr.model.Address;
import usr.model.User;
import usr.service.ActivityService;
import usr.service.AddressService;
import usr.service.UserService;

@Component
public class TestData {

	@Autowired
	UserService usser;
	
	@Autowired
	AddressService asser;
	
	@Autowired
	ActivityService activityService;
	
	@PostConstruct
	private void init(){
		for(int i=1; i<=45; i++){
			User user = new User();
			user.setFirstname("First name " + i);
			user.setLastname("Last name " + i);
			user.setEmail("email " + i + "@example.com");
			user.setPassword("123");
			usser.save(user);
			
			for(int j = 1; j<=3; j++){
				Address addr = new Address();
				addr.setNumber(j + "c/7");
				addr.setStreet("Narodnog fronta");
				
				addr.setUser(user);
				user.addAddresses(addr);
				asser.save(addr);
			}
			Activity a = new Activity("Activity" + i);
			activityService.save(a);
		}
	}
}
