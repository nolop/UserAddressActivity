package usr.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import usr.model.User;
import usr.service.UserService;
import usr.web.dto.UserDto;

@Component
public class UserDtoToUser implements Converter<UserDto, User> {

	@Autowired
	private UserService use;
	
	@Autowired
	AddressDtoToAddress toAdr;
	
	@Override
	public User convert(UserDto dto) {
		User user = null;
		
		if(dto.getId()!=null)
			user = use.findOne(dto.getId());
		else
			user = new User();
		
		user.setEmail(dto.getEmail());
		user.setFirstname(dto.getFirstname());
		user.setId(dto.getId());
		user.setLastname(dto.getLastname());
		user.setPassword(dto.getPassword());
		return user;
	}

	public List<User> convertAll(List<UserDto> dtos){
		List<User> users = new ArrayList<User>();
		
		for(UserDto dto : dtos)
			users.add(convert(dto));
			
		return users;
	}

}
