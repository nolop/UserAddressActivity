package usr.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import usr.model.Address;
import usr.service.AddressService;
import usr.web.dto.AddressDto;

@Component
public class AddressDtoToAddress implements Converter<AddressDto, Address>{

	@Autowired
	AddressService asse;
	
	@Autowired
	UserDtoToUser toUsr;
	
	@Override
	public Address convert(AddressDto dto) {
		Address ret = null;
		if(dto.getId()!=null)
			ret = asse.findOne(dto.getId());
		else
			ret = new Address();
		
		ret.setId(dto.getId());
		ret.setNumber(dto.getNumber());
		ret.setStreet(dto.getStreet());
		
		return ret;
	}
	
	public List<Address> convertAll(List<AddressDto> dtos){
		List<Address> ret = new ArrayList<Address>(); 
		for(AddressDto dto : dtos)
			ret.add(convert(dto));
		return ret;
	}

}
