package usr.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import usr.model.Activity;
import usr.web.dto.ActivityDto;

@Component
public class ActivityToActivityDto implements Converter<Activity, ActivityDto>{

	@Override
	public ActivityDto convert(Activity act) {
		ActivityDto dto = new ActivityDto();
		
		dto.setId(act.getId());
		dto.setName(act.getName());
		
		return dto;
	}
	
	public List<ActivityDto> convertAll(List<Activity> acts){
		List<ActivityDto> dtos = new ArrayList<ActivityDto>();
		
		for(Activity act : acts)
			dtos.add(convert(act));
		
		return dtos;
	}

}
