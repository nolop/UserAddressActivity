package usr.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import usr.model.User;
import usr.web.dto.UserDto;

@Component
public class UserToUserDto implements Converter<User, UserDto>{

	@Autowired
	AddressToAddressDto toDto;
	
	@Override
	public UserDto convert(User us) {
		UserDto dto = new UserDto();
		
		dto.setEmail(us.getEmail());
		dto.setFirstname(us.getFirstname());
		dto.setId(us.getId());
		dto.setLastname(us.getLastname());
		dto.setPassword(us.getPassword());
		return dto;
	}
	
	public List<UserDto> convertAll(List<User> uss){
		List<UserDto> dtos = new ArrayList<UserDto>();
		
		for(User us : uss)
			dtos.add(convert(us));
		
		return dtos;
	}

}
