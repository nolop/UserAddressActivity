package usr.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import usr.model.Activity;
import usr.service.ActivityService;
import usr.web.dto.ActivityDto;

@Component
public class ActivityDtoToActivity implements Converter<ActivityDto, Activity>{

	@Autowired
	private ActivityService ase;
	
	@Override
	public Activity convert(ActivityDto dto) {
		Activity activity = null;
		
		if(dto.getId()!=null)
			activity = ase.findOne(dto.getId());
		else
			activity = new Activity();
		activity.setId(dto.getId());
		activity.setName(dto.getName());
		
		return activity;
	}
	
	public List<Activity> convertAll(List<ActivityDto> dtos){
		List<Activity> ret = new ArrayList<Activity>();
		
		for(ActivityDto dto : dtos)
			ret.add(convert(dto));
		
		return ret;
	}

}
