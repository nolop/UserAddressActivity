package usr.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import usr.model.Address;
import usr.web.dto.AddressDto;

@Component
public class AddressToAddressDto implements Converter<Address, AddressDto> {

	@Autowired
	UserToUserDto toDto;
	
	@Override
	public AddressDto convert(Address adr) {
		AddressDto dto = null;
		if(adr!=null){
			dto = new AddressDto();
			dto.setId(adr.getId());
			dto.setNumber(adr.getNumber());
			dto.setStreet(adr.getStreet());
			dto.setUsrId(adr.getUser().getId());
			return dto;
		}
		return null;
	}

	public List<AddressDto> convertAll(List<Address> adrs){
		List<AddressDto> dtos = new ArrayList<AddressDto>();
		for(Address adr : adrs)
			dtos.add(convert(adr));
		return dtos;
	}
}
