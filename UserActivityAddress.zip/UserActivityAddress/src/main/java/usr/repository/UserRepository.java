package usr.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import usr.model.User;

@Repository
public interface UserRepository extends PagingAndSortingRepository<User, Long>{

	//@Query("SELECT u FROM User u WHERE u.name like %:name%")
	List<User> findByFirstnameContaining(String name);
	//List<User> findByNameContaining(String name);
}
