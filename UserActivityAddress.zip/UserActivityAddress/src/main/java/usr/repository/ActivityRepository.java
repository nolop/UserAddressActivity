package usr.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import usr.model.Activity;

@Repository
public interface ActivityRepository extends PagingAndSortingRepository<Activity, Long>{//JpaRepository<Activity, Long>{

	List<Activity> findByNameContaining(String name);
	
	List<Activity> findAll();
}
