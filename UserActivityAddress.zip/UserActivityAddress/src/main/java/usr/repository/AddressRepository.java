package usr.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import usr.model.Address;
import usr.model.User;

@Repository
public interface AddressRepository extends PagingAndSortingRepository<Address, Long>{

	List<Address> findByStreetAndNumber(String street, String number);
	
	List<Address> findByUserId(long userId);
	
	List<Address> findByUser(User user);
	
	List<Address> findAll();
}
