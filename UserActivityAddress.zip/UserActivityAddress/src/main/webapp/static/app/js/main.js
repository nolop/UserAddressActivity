
var userApp = angular.module('userApp', ['ngRoute']);

userApp.config(function($routeProvider){
	$routeProvider
			.when('/',{
				templateUrl : '/static/app/html/partial/home.html'
			})
			.when('/activities', {
				templateUrl : '/static/app/html/partial/activities.html',
				controller: 'activitiesCtrl'
			})
			.when('/activity/:id', {
				templateUrl: '/static/app/html/partial/activity.html',
				controller: 'activityCtrl'
			})
			/*
			.when('/addresses', {
				templateUrl : '/static/app/html/partial/addresses.html',
				controller : 'addressesCtrl'
			})
			*/
			.when('/address/:id', {
				templateUrl : '/static/app/html/partial/address.html',
				controller : 'addressCtrl'
			})
			.when('/user/:id', {
				templateUrl: '/static/app/html/partial/user.html',
				controller: 'userCtrl'
			})
			.when('/users', {
				templateUrl : '/static/app/html/partial/users.html',
				controller: 'usersCtrl'
			})
			.when('/blabla', {
				templateUrl : '/static/app/html/partial/blabla.html'
			})
			.otherwise({
				redirectTo: '/'
			});
});

userApp.controller('activitiesCtrl', function($scope, $location, $http){
	var loadActivities = function(){
		$http.get('api/activities')
		.success(function(data, code){
			$scope.activities = data;
			console.log(code);
		})
		.error(function(data, code){
			console.log('data: ' + data);
			console.log('code: ' + code);
		});
	}
	loadActivities();
	$scope.deleteAct = function(id){
		console.log('brisanje id: ' + id);
		$http.delete('api/activities/' + id)
		.success(function(data, code){
			console.log('success ' + data + ':' + code)
			loadActivities();
		})
		.error(function(data, code){
			console.log('error: ' + data + ':' + code)
		});
	}
	$scope.saveAct = function(){
		if($scope.act.id){
			$http.put('api/activities/' + $scope.act.id, $scope.act)
			.success(function(){
				loadActivities();
				$scope.act = {};
			})
			.error(function(data, code){
				console.log('error: ' + data + ':' + code)
			});
		}
		else{
			$http.post('api/activities', $scope.act)
			.success(function(data, code){
				console.log('success'  + data + ':' + code)
				loadActivities();
				$scope.act = {};
			})
			.error(function(data, code){
				console.log('error '  + data + ':' + code)
			});
		}
	}
	$scope.editAct = function(activity){
		$scope.act = {};
		$scope.act.name = activity.name;
		$scope.act.id = activity.id;
		console.log($scope.act);
	}
	$scope.editInNewPageAct = function(activity){
		$location.path('activity/' + activity.id);
	}
	$scope.findAct = function(){
		var parameters = {};
		parameters.name = $scope.fiAct;
		$http.get('api/activities', {params:parameters})
		.success(function(data, code){
			console.log('success: ' + data + ':' + code);
			$scope.activities = data;
			$scope.act = {};
		})
		.error(function(data, code){
			console.log('error: ' + data + ':' + code);
		});
	}
});

userApp.controller('activityCtrl', function($http, $location, $scope, $routeParams){
	var id = $routeParams.id;
	$http.get('api/activities/' + id)
	.success(function(data){
		$scope.act = data;
	});

	$scope.saveAct = function(){
		$http.put('api/activities/' + id, $scope.act)
		.success(function(){
			$location.path('activities');
		});
	}
});

userApp.controller('usersCtrl', function($scope, $location, $http){
	$scope.page = 1;
	$scope.changePage = function(i){
		$scope.page += i;
		console.log(i);
		loadUsr();
	}

	var loadUsr = function(){
		var parameters = {};
		parameters.page = $scope.page;
		$http.get('api/users', {params:parameters})
		.success(function(data, code){
			$scope.users = data;
			console.log('success: ' + data + ':' +code);	
		})
		.error(function(data, code){
			console.log('error! : ' + data + ':' + code);
		});
	}
	loadUsr();
	$scope.deleteUsr = function(id){
		console.log('brisanje id: ' + id);
		$http.delete('api/users/' + id)
		.success(function(data, code){
			console.log('success: ' + data + ':' + code);
			loadUsr();
		})
		.error(function(data, code){
			console.log('error: ' + data + ':' + code);
		});
	}
	$scope.saveUsr = function(){
		if($scope.usr.id){
			$http.put('api/users/' + $scope.usr.id, $scope.usr)
			.success(function(){
				loadUsr();
				$scope.usr = {};
			})
			.error(function(data, code){
				console.log('put');
				console.log('error: ' + data + ':' + code);
			})
		}
		else{
			$http.post('api/users/', $scope.usr)
			.success(function(data, code){
				console.log('success: ' + data + ':' + code);
				loadUsr();
				$scope.usr = {};
			})
			.error(function(data, code){
				console.log('post');
				console.log('error: ' + data + ':' + code);
			});
		}
	}

	$scope.editUsr = function(user){
		$scope.usr = {};
		$scope.usr.firstname = user.firstname;
		$scope.usr.lastname = user.lastname;
		$scope.usr.email = user.email;
		$scope.usr.password = user.password;
		$scope.usr.id = user.id;
		console.log($scope.usr);
	}
	$scope.editInNewPageUsr = function(user){
		$location.path('user/' + user.id);
	}
	
});

userApp.controller('userCtrl', function($http, $location, $scope, $routeParams){
	var id = $routeParams.id;
	$http.get('api/users/' + id)
	.success(function(data){
		$scope.usr = data;
	})
	.error(function(data, code){
		console.log('error: ' + data + ':' + code);
	});
	$scope.saveUsr = function(){
		$http.put('api/users/' + id, $scope.usr)
		.success(function(){
			$location.path('users');
		});
	}
	var loadAddr = function(){
		$http.get('api/addresses/user/' + id)
		.success(function(data, code){
			$scope.addrs = data;			
		})
		.error(function(data, code){
			console.log('error: ' + data + ':' + code)
		});
	}
	loadAddr();
	$scope.deleteAddr = function(id){
		$http.delete('/api/addresses/' + id)
		.success(function(data, code){
			console.log('success ' + data + ' : ' + code);
			loadAddr();
		})
		.error(function(data, code){
			console.log('success ' + data + ' : ' + code);
		});
	}
	$scope.saveAddr = function(usrId){
		if($scope.addr.id){
			console.log($scope.addr);
			$http.put('api/addresses/' + $scope.addr.id + '/user/' + usrId, $scope.addr)
			.success(function(data, code){
				console.log('bla bla' + $scope.addr.numb);
				console.log('success put:' + data + ':' + code);
				loadAddr();
				$scope.addr = {};
			})
			.error(function(data, code){
				console.log('error put: ' + data + ':' + code);
			})
		}
		else{
			console.log($scope.addr);
			$http.post('api/addresses/user/' + usrId, $scope.addr)
			.success(function(data, code){
				console.log('success post:' + data + ':' + code);
				loadAddr();
				$scope.addr = {};
			})
			.error(function(data, code){
				console.log('error post: ' + data + ':' + code);
			});
		}	
    }

	$scope.editAddr = function(address){
		$scope.addr = {};
		$scope.addr.street = address.street;
		$scope.addr.number = address.number;
		$scope.addr.id = address.id;
		$scope.addr.usrId = address.usrId;
		console.log($scope.addr); 
	}
	
	$scope.editInNewPageAddr = function(address){
		$location.path('address/' + address.id);	
	}
	/*
	$http.get('api/addresses/users/' + id)
	.success(function(data){
		$scope.addrs = data;
	})
	.error(function(data, code){
		console.log('error: ' + data + ':' + code);
	});
	*/
	
});

userApp.controller('addressesCtrl', function($scope, $http, $location){
	//var usId = $routeParams.id;
	var loadAddr = function(){
		$http.get('api/addresses')
		.success(function(data, code){
			$scope.addresses = data;			
		})
		.error(function(data, code){
			console.log('error: ' + data + ':' + code)
		});
	}
	loadAddr();

	$scope.deleteAddr = function(id){
		$http.delete('/api/addresses/' + id)
		.success(function(data, code){
			console.log('success ' + data + ' : ' + code);
			loadAddr();
		})
		.error(function(data, code){
			console.log('success ' + data + ' : ' + code);
		});
	}

	$scope.saveAddr = function(usrId){
		if($scope.addr.id){
			$http.put('api/addresses/' + $scope.addr.id + '/user/' + usrId, $scope.addr)
			.success(function(data, code){
				console.log('bla bla' + $scope.addr.numb);
				console.log('success put:' + data + ':' + code);
				loadAddr();
				$scope.addr = {};
			})
			.error(function(data, code){
				console.log('error put: ' + data + ':' + code);
			})
		}
		else{
			$http.post('api/addresses/user/' + usrId, $scope.addr)
			.success(function(data, code){
				console.log('success post:' + data + ':' + code);
				loadAddr();
				$scope.addr = {};
			})
			.error(function(data, code){
				console.log('error post: ' + data + ':' + code);
			});
		}	
    }

	$scope.editAddr = function(address){
		$scope.addr = {};
		$scope.addr.street = address.street;
		$scope.addr.number = address.number;
		$scope.addr.id = address.id;
		$scope.addr.usrId = address.usrId;
		console.log($scope.addr); 
	}
	
	$scope.editInNewPageAddr = function(address){
		$location.path('address/' + address.id);	
	}
});	

userApp.controller('addressCtrl', function($http, $location, $scope, $routeParams){
	var id = $routeParams.id;
	$http.get('api/addresses/' + id)
	.success(function(data){
		$scope.addr = data;
		console.log($scope.addr);
	});
	$scope.saveAddr = function(id){
		$http.put('api/addresses/' + $scope.addr.id + '/user/' + id, $scope.addr)
		.success(function(data, code){
			console.log('success put:' + data + ':' + code);
			$location.path('user/' + id);	
			$scope.addr = {};
		})
		.error(function(data, code){
			console.log('error put: ' + data + ':' + code);
		});
    }
});
